I / Etapes pour installer notre map Minecraft :
 - Extraire les fichiers de la Map du .zip
 - Accéder au dossier Minecraft :
	- Win + R pour ouvrir la boîte de dialogue "Exécuter".
	- %appdata% et appuiez sur "Entrée".
	- Accède au dossier .minecraft.
 - Installer la Map :
	- Dans le dossier .minecraft, recherchez le dossier "saves". C'est là que vous devrez 	placer la map.
	- Copiez le dossier de la map que vous avez extrait précédemment.
	- Collez le dossier dans le dossier "saves".
 - Lancer Minecraft
 - Jouer -> Monde Solo 


II / Objectif de la map
Vous apparaitrez dans une pièce dans laquelle se trouve un bouton, cliquez dessus pour commencer la carte.
Cette carte vous confrontera à plusieurs choix qui vous feront avancer dans l'histoire !
Pas de mod requis pour la carte.